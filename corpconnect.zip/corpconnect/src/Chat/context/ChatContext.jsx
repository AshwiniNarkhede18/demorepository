// import React, { createContext, useState, useContext } from 'react';

// const ChatContext = createContext();

// export const ChatProvider = ({ children }) => {
//     const [messages, setMessages] = useState([]);

//     const addMessage = (msg) => {
//         setMessages(prev => [...prev, msg]);
//     };

//     return (
//         <ChatContext.Provider value={{ messages, addMessage }}>
//             {children}
//         </ChatContext.Provider>
//     );
// };

// export const useChat = () => {
//     const context = useContext(ChatContext);
//     if (!context) {
//         throw new Error('useChat must be used within a ChatProvider');
//     }
//     return context;
// };

import { createContext, useState } from "react";

export const ChatContext = createContext();

export const ChatProvider = ({ children }) => {
  const [jwt, setJwt] = useState("");
  const [ticketId, setTicketId] = useState(null);
  const [isChatOpen, setIsChatOpen] = useState(false);

  const openChat = (ticket, token) => {
    setTicketId(ticket);
    setJwt(token);
    setIsChatOpen(true);
  };

  const closeChat = () => setIsChatOpen(false);

  return (
    <ChatContext.Provider
      value={{ jwt, ticketId, isChatOpen, openChat, closeChat }}
    >
      {children}
    </ChatContext.Provider>
  );
};
