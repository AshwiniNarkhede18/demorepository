import React from 'react'

export const CandidateHome = () => {
    return (
        <div>
            
        </div>
    )
}
