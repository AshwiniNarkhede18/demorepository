import React from 'react';

export const Footer = () => {
  return (
    <>
      <p className="text-center">&copy; All Rigths Reserved By CorpConnect</p>
    </>
  );
};
