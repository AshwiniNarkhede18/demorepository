package com.company.user_service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.company.user_service.entity.User;
import com.google.common.base.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
    java.util.Optional<com.company.user_service.entity.User> findByEmail(String email);
}
