package com.company.user_service.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.company.user_service.dto.AuthResponse;
import com.company.user_service.dto.FileUploadRequest;
import com.company.user_service.dto.FileUploadResponse;
import com.company.user_service.dto.LoginRequest;
import com.company.user_service.dto.RegisterRequest;
import com.company.user_service.dto.UserDto;
import com.company.user_service.entity.FileMetadata;
import com.company.user_service.entity.Role;
import com.company.user_service.entity.User;
import com.company.user_service.entity.UserRole;
import com.company.user_service.minio.MinioUtil;
import com.company.user_service.outbox.EventOutboxService;
import com.company.user_service.repo.FileMetadataRepository;
import com.company.user_service.repo.OutboxRepository;
import com.company.user_service.repo.RoleRepository;
import com.company.user_service.repo.UserRepository;
import com.company.user_service.repo.UserRoleRepository;
import com.company.user_service.security.JwtUtil;

import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.NotFoundException;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserRoleRepository userRoleRepository;
    private final FileMetadataRepository fileMetadataRepository;
    private final OutboxRepository outboxRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final MinioUtil minioUtil;
    private final EventOutboxService eventOutboxService;
    private final AuthenticationManager authenticationManager;
    private final RestTemplate restTemplate;

    @Value("${security.jwt.expiration-ms:3600000}")
    private long jwtExpiryMs;

    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           UserRoleRepository userRoleRepository,
                           FileMetadataRepository fileMetadataRepository,
                           OutboxRepository outboxRepository,
                           PasswordEncoder passwordEncoder,
                           JwtUtil jwtUtil,
                           MinioUtil minioUtil,
                           EventOutboxService eventOutboxService,
                           AuthenticationManager authenticationManager,
                           RestTemplate restTemplate) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.userRoleRepository = userRoleRepository;
        this.fileMetadataRepository = fileMetadataRepository;
        this.outboxRepository = outboxRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
        this.minioUtil = minioUtil;
        this.eventOutboxService = eventOutboxService;
        this.authenticationManager = authenticationManager;
        this.restTemplate = restTemplate;
    }

    @Override
    @Transactional
    public UserDto register(RegisterRequest request) {
        userRepository.findByEmail(request.getEmail()).ifPresent(u -> {
            throw new BadRequestException("Email already in use");
        });

        User user = new User();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setStatus("ACTIVE");
        user = userRepository.save(user);

        // Optionally assign default role EMPLOYEE
        Role employeeRole = roleRepository.findByName("EMPLOYEE");
        if (employeeRole != null) {
            UserRole ur = new UserRole();
            ur.setUserId(user.getId());
            ur.setRoleId(employeeRole.getId());
            userRoleRepository.save(ur);
        }

        // Enqueue outbox event (USER_CREATED)
        Map<String, Object> payload = new HashMap<>();
        payload.put("userId", user.getId());
        payload.put("email", user.getEmail());
        payload.put("fullName", user.getFullName());
        eventOutboxService.enqueue("USER_CREATED", payload, user.getId());

        return toDto(user);
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );

            // Get authenticated user details
            org.springframework.security.core.userdetails.User principal =
                    (org.springframework.security.core.userdetails.User) authentication.getPrincipal();

            // Generate JWT token
            String token = jwtUtil.generateToken(principal);

            return new AuthResponse(token, jwtExpiryMs);

        } catch (org.springframework.security.core.AuthenticationException ex) {
            throw new RuntimeException("Invalid email or password");  // or your custom UnauthorizedException
        }
    }


    @Override
    public UserDto getById(String id) {
        User u = userRepository.findById(id).orElseThrow(() -> new NotFoundException("User not found"));
        List<Role> roles = roleRepository.findRolesByUserId(u.getId());
        UserDto dto = toDto(u);
        dto.setRoles(roles.stream().map(Role::getName).collect(Collectors.toList()));
        return dto;
    }

    @Override
    public List<UserDto> listAll(int page, int size) {
        Page<User> p = userRepository.findAll(PageRequest.of(page, size));
        return p.stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    @PreAuthorize("hasRole('ADMIN')")
    @Transactional
    public void assignRole(String userId, String roleName) {
        User user = userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found"));
        Role role = roleRepository.findByName(roleName);
        if (role == null) throw new NotFoundException("Role not found");

        // check existing
        List<UserRole> existing = userRoleRepository.findByUserId(userId);
        boolean already = existing.stream().anyMatch(ur -> ur.getRoleId().equals(role.getId()));
        if (already) return;

        UserRole ur = new UserRole();
        ur.setUserId(userId);
        ur.setRoleId(role.getId());
        userRoleRepository.save(ur);

        // enqueue event
        Map<String, Object> payload = new HashMap<>();
        payload.put("userId", userId);
        payload.put("role", roleName);
        eventOutboxService.enqueue("USER_ROLE_ASSIGNED", payload, userId);
    }

    @Override
    @Transactional
    public FileUploadResponse presignUpload(FileUploadRequest req) {
        // Create file metadata row
        FileMetadata fm = new FileMetadata();
        fm.setFileName(req.getFileName());
        String objectKey = String.format("%s/%s/%s_%s", req.getOwnerType().toLowerCase(),
                req.getOwnerId(), UUID.randomUUID().toString(), req.getFileName());
        fm.setObjectKey(objectKey);
        fm.setMimeType(req.getMimeType());
        fm.setUploadedBy(req.getOwnerId());
        fm.setSize(null);
        fileMetadataRepository.save(fm);

        // create presigned URL
        String uploadUrl = minioUtil.presignedPutObject(objectKey, 60 * 5); // 5 min
        return new FileUploadResponse(fm.getId(), objectKey, uploadUrl);
    }

    @Override
    @Transactional
    public void confirmUpload(String fileId) {
        FileMetadata fm = fileMetadataRepository.findById(fileId)
                .orElseThrow(() -> new NotFoundException("File metadata not found"));
        boolean exists = minioUtil.objectExists(fm.getObjectKey());
        if (!exists) throw new BadRequestException("Object not found on MinIO");

        // mark uploaded (set uploadedAt)
        // (Assuming FileMetadata entity has uploadedAt field and status if needed)
        // Here we just update uploadedAt via repository
        // (Implement setter in entity)
        fm.setUploadedAt(java.time.Instant.now());
        fileMetadataRepository.save(fm);

        // optionally set user.profileFileId if owner type is USER
        // For safety, try to update user
        try {
            User user = userRepository.findById(fm.getUploadedBy()).orElse(null);
            if (user != null) {
                user.setProfileFileId(fm.getId());
                userRepository.save(user);
            }
        } catch (Exception ex) {
            // log but don't fail
        }

        // enqueue event if needed
        Map<String, Object> payload = Map.of("fileId", fm.getId(), "objectKey", fm.getObjectKey());
        eventOutboxService.enqueue("FILE_UPLOADED", payload, fm.getId());
    }

    private UserDto toDto(User u) {
        UserDto dto = new UserDto();
        dto.setId(u.getId());
        dto.setFullName(u.getFullName());
        dto.setEmail(u.getEmail());
        dto.setProfileFileId(u.getProfileFileId());

        // ✅ Get roles from RoleRepository
        List<Role> roleList = roleRepository.findRolesByUserId(u.getId());
        List<String> roles = roleList.stream().map(Role::getName).toList();

        dto.setRoles(roles);

        return dto;
    }

    @Override
    public UserDto getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found with email: " + email));

        // ✅ Fetch roles from RoleRepository instead of user.getRoles()
        List<Role> roleList = roleRepository.findRolesByUserId(user.getId());
        List<String> roles = roleList.stream().map(Role::getName).toList();

        UserDto dto = new UserDto();
        dto.setId(user.getId());
        dto.setFullName(user.getFullName());
        dto.setEmail(user.getEmail());
        dto.setProfileFileId(user.getProfileFileId());
        dto.setRoles(roles);

        return dto;
    }

}
