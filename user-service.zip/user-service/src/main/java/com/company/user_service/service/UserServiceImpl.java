package com.company.user_service.service;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.company.user_service.dto.AuthResponse;
import com.company.user_service.dto.FileUploadRequest;
import com.company.user_service.dto.FileUploadResponse;
import com.company.user_service.dto.LoginRequest;
import com.company.user_service.dto.RegisterRequest;
import com.company.user_service.dto.UserDto;
import com.company.user_service.entity.FileMetadata;
import com.company.user_service.entity.Role;
import com.company.user_service.entity.User;
import com.company.user_service.entity.UserRole;
import com.company.user_service.minio.MinioUtil;
import com.company.user_service.outbox.EventOutboxService;
import com.company.user_service.repo.FileMetadataRepository;
import com.company.user_service.repo.OutboxRepository;
import com.company.user_service.repo.RoleRepository;
import com.company.user_service.repo.UserRepository;
import com.company.user_service.repo.UserRoleRepository;
import com.company.user_service.security.JwtUtil;

import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.NotFoundException;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserRoleRepository userRoleRepository;
    private final FileMetadataRepository fileMetadataRepository;
    private final OutboxRepository outboxRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final MinioUtil minioUtil;
    private final EventOutboxService eventOutboxService;
    private final AuthenticationManager authenticationManager;
    private final RestTemplate restTemplate;

    @Value("${security.jwt.expiration-ms:3600000}")
    private long jwtExpiryMs;

    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           UserRoleRepository userRoleRepository,
                           FileMetadataRepository fileMetadataRepository,
                           OutboxRepository outboxRepository,
                           PasswordEncoder passwordEncoder,
                           JwtUtil jwtUtil,
                           MinioUtil minioUtil,
                           EventOutboxService eventOutboxService,
                           AuthenticationManager authenticationManager,
                           RestTemplate restTemplate) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.userRoleRepository = userRoleRepository;
        this.fileMetadataRepository = fileMetadataRepository;
        this.outboxRepository = outboxRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
        this.minioUtil = minioUtil;
        this.eventOutboxService = eventOutboxService;
        this.authenticationManager = authenticationManager;
        this.restTemplate = restTemplate;
    }

    @Override
    @Transactional
    public UserDto register(RegisterRequest request) {
        userRepository.findByEmail(request.getEmail()).ifPresent(u -> {
            throw new BadRequestException("Email already in use");
        });

        // Validate department
        String dept = request.getDepartment();
        if (dept == null || dept.isBlank()) {
            throw new BadRequestException("Department is required");
        }

        // create user
        User u = new User();
        u.setId(UUID.randomUUID().toString());
        u.setFullName(request.getFullName());
        u.setEmail(request.getEmail());
        u.setPassword(passwordEncoder.encode(request.getPassword()));
        u.setStatus("ACTIVE");
        u.setDepartment(dept.toUpperCase());
        u.setCreatedAt(Instant.now());

        userRepository.save(u);

        // assign default EMPLOYEE role automatically
        Role emp = roleRepository.findByName("ROLE_EMPLOYEE")
                .orElseThrow(() -> new RuntimeException("Role EMPLOYEE not found"));
        if (emp != null) {
            UserRole ur = new UserRole();
            ur.setUserId(u.getId());
            ur.setRoleId(emp.getId());
            userRoleRepository.save(ur);
        }

        return toDto(u);
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );

            // Get authenticated user details
            org.springframework.security.core.userdetails.User principal =
                    (org.springframework.security.core.userdetails.User) authentication.getPrincipal();

            // Generate JWT token
            String token = jwtUtil.generateToken(principal);

            return new AuthResponse(token, jwtExpiryMs);

        } catch (org.springframework.security.core.AuthenticationException ex) {
            throw new RuntimeException("Invalid email or password");  // or your custom UnauthorizedException
        }
    }


    @Override
    public UserDto getById(String id) {
        User u = userRepository.findById(id).orElseThrow(() -> new NotFoundException("User not found"));
        List<Role> roles = roleRepository.findRolesByUserId(u.getId());
        UserDto dto = toDto(u);
        dto.setRoles(roles.stream().map(Role::getName).collect(Collectors.toList()));
        return dto;
    }

    @Override
    public List<UserDto> listAll(int page, int size) {
        return userRepository.findAll()
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }


    @Override
    @Transactional
    public void assignRole(String userId, String roleName) {
        User user = userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found"));
        Role role = roleRepository.findByName("ROLE_EMPLOYEE")
                .orElseThrow(() -> new RuntimeException("Role EMPLOYEE not found"));
        if (role == null) throw new NotFoundException("Role not found: " + roleName);

        // If assigning a department-head role, ensure user has a department set
        if (roleName.equals("MANAGER") || roleName.equals("HR_HEAD") || roleName.equals("ITS_HEAD")) {
            if (user.getDepartment() == null || user.getDepartment().isBlank()) {
                throw new BadRequestException("User must have a department before assigning department-head role");
            }
            // optionally: ensure this role is unique per department (i.e., only one head)
            List<User> existingHeads = userRepository.findDepartmentHeads()
                    .stream()
                    .filter(u -> user.getDepartment().equalsIgnoreCase(u.getDepartment()))
                    .collect(Collectors.toList());
            // If you want single head-per-department, uncomment below:
            // if (!existingHeads.isEmpty()) throw new BadRequestException("Department already has a head: " + existingHeads.get(0).getEmail());
        }

        // Check if already assigned
        List<Role> current = roleRepository.findRolesByUserId(userId);
        boolean already = current.stream().anyMatch(r -> r.getName().equals(roleName));
        if (already) return;

        UserRole ur = new UserRole();
        ur.setUserId(userId);
        ur.setRoleId(role.getId());
        userRoleRepository.save(ur);
    }

    @Override
    @Transactional
    public FileUploadResponse presignUpload(FileUploadRequest req) {
        // Create file metadata row
        FileMetadata fm = new FileMetadata();
        fm.setFileName(req.getFileName());
        String objectKey = String.format("%s/%s/%s_%s", req.getOwnerType().toLowerCase(),
                req.getOwnerId(), UUID.randomUUID().toString(), req.getFileName());
        fm.setObjectKey(objectKey);
        fm.setMimeType(req.getMimeType());
        fm.setUploadedBy(req.getOwnerId());
        fm.setSize(null);
        fileMetadataRepository.save(fm);

        // create presigned URL
        String uploadUrl = minioUtil.presignedPutObject(objectKey, 60 * 5); // 5 min
        return new FileUploadResponse(fm.getId(), objectKey, uploadUrl);
    }

    @Override
    @Transactional
    public void confirmUpload(String fileId) {
        FileMetadata fm = fileMetadataRepository.findById(fileId)
                .orElseThrow(() -> new NotFoundException("File metadata not found"));
        boolean exists = minioUtil.objectExists(fm.getObjectKey());
        if (!exists) throw new BadRequestException("Object not found on MinIO");

        // mark uploaded (set uploadedAt)
        // (Assuming FileMetadata entity has uploadedAt field and status if needed)
        // Here we just update uploadedAt via repository
        // (Implement setter in entity)
        fm.setUploadedAt(java.time.Instant.now());
        fileMetadataRepository.save(fm);

        // optionally set user.profileFileId if owner type is USER
        // For safety, try to update user
        try {
            User user = userRepository.findById(fm.getUploadedBy()).orElse(null);
            if (user != null) {
                user.setProfileFileId(fm.getId());
                userRepository.save(user);
            }
        } catch (Exception ex) {
            // log but don't fail
        }

        // enqueue event if needed
        Map<String, Object> payload = Map.of("fileId", fm.getId(), "objectKey", fm.getObjectKey());
        eventOutboxService.enqueue("FILE_UPLOADED", payload, fm.getId());
    }

    // existing helpers
    private UserDto toDto(User u) {
        UserDto dto = new UserDto();
        dto.setId(u.getId());
        dto.setFullName(u.getFullName());
        dto.setEmail(u.getEmail());
        dto.setProfileFileId(u.getProfileFileId());
        dto.setDepartment(u.getDepartment());

        // load roles via repository helper
        List<Role> roles = roleRepository.findRolesByUserId(u.getId()); // ensure this exists
        dto.setRoles(roles == null ? List.of() : roles.stream().map(Role::getName).collect(Collectors.toList()));

        return dto;
    }

    @Override
    public UserDto getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new NotFoundException("User not found: " + email));
        return toDto(user);
    }
    
    
//    @Override
//    public UserDto getById(String id) {
//        User u = userRepository.findById(id).orElseThrow(() -> new NotFoundException("User not found"));
//        return toDto(u);
//    }

    @Override
    public List<UserDto> getEmployeesUnderHead(String headId) {
        User head = userRepository.findById(headId).orElseThrow(() -> new NotFoundException("Head not found"));
        String dept = head.getDepartment();
        if (dept == null) throw new BadRequestException("Head has no department");

        // find employees in same department (exclude other heads)
        List<User> employees = userRepository.findEmployeesByDepartment(dept);
        return employees.stream().map(this::toDto).collect(Collectors.toList());
    }
    
    @Override
    public List<UserDto> getEmployeesByDepartment(String department) {
        List<User> users = userRepository.findByDepartment(department.toUpperCase());
        return users.stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public List<UserDto> getDepartmentHeads() {
        List<User> heads = userRepository.findDepartmentHeads();
        return heads.stream().map(this::toDto).collect(Collectors.toList());
    }
   
}
