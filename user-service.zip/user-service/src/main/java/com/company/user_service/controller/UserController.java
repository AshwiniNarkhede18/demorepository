package com.company.user_service.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.user_service.dto.FileUploadRequest;
import com.company.user_service.dto.FileUploadResponse;
import com.company.user_service.dto.UserDto;
import com.company.user_service.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    public UserController(UserService userService) { this.userService = userService; }

//    @GetMapping("/me")
//    public ResponseEntity<UserDto> me(Authentication authentication) {
//        String email = authentication.getName();
//        // find user by email (service might need method)
//        // For now assume getById not by email - call repository via service if added
//        // We'll call getById after fetching user id via RestTemplate to user-service itself, but simplified:
//        // Implement an additional method in service if needed.
//        return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).build();
//    }
    
    @GetMapping("/me")
    public ResponseEntity<UserDto> me() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();

        UserDto user = userService.getUserByEmail(email);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or #id == authentication.principal?.username")
    public ResponseEntity<UserDto> getById(@PathVariable String id) {
        UserDto dto = userService.getById(id);
        return ResponseEntity.ok(dto);
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<UserDto>> listAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        List<UserDto> list = userService.listAll(page, size);
        return ResponseEntity.ok(list);
    }

    @PostMapping("/{id}/roles")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> assignRole(@PathVariable String id, @RequestBody Map<String,String> body) {
        String role = body.get("role");
        userService.assignRole(id, role);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/files/presign")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<FileUploadResponse> presignUpload(@Valid @RequestBody FileUploadRequest req) {
        FileUploadResponse resp = userService.presignUpload(req);
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/files/complete")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> completeUpload(@RequestBody Map<String,String> body) {
        String fileId = body.get("fileId");
        userService.confirmUpload(fileId);
        return ResponseEntity.ok().build();
    }
}
