package com.company.user_service.entity;

import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name="roles")
public class Role {
    @Id
    @Column(length=36)
    private String id;

    @Column(unique=true, nullable=false)
    private String name;

    @PrePersist
    public void prePersist() {
        if (this.id == null) this.id = UUID.randomUUID().toString();
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Role orElseThrow(Object object) {
		// TODO Auto-generated method stub
		return null;
	}
    
    
    
}
