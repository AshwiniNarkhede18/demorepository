package com.company.tickert_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TickertServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
