package com.company.tickert_service.service;

import java.util.List;
import com.company.tickert_service.dto.CreateTicketRequest;
import com.company.tickert_service.dto.TicketResponse;
import com.company.tickert_service.dto.CommentRequest;
public interface TicketService {
    TicketResponse createTicket(CreateTicketRequest req, String requesterId);
    List<TicketResponse> getMyTickets(String userId);
    List<TicketResponse> getDeptTickets(String departmentId);
    void assignTicket(String ticketId, String assignedTo, String performedBy);
    void addComment(String ticketId, CommentRequest req, String senderId);
    void closeTicket(String ticketId, String performedBy);
}
