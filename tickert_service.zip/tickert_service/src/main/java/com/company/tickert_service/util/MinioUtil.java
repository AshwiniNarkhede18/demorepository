package com.company.tickert_service.util;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.ZonedDateTime;
import io.minio.GetPresignedObjectUrlArgs;
import io.minio.MinioClient;
import io.minio.errors.ErrorResponseException;
import io.minio.errors.InsufficientDataException;
import io.minio.errors.InternalException;
import io.minio.errors.InvalidResponseException;
import io.minio.errors.ServerException;
import io.minio.errors.XmlParserException;
import io.minio.http.Method;

@Component
public class MinioUtil {
    private final MinioClient minioClient;
    private final String bucket = "company-files";

    public MinioUtil(MinioClient minioClient) {
        this.minioClient = minioClient;
    }

    public String presignPut(String objectKey, int expirySeconds) throws InvalidKeyException, ErrorResponseException, InsufficientDataException, InternalException, InvalidResponseException, NoSuchAlgorithmException, XmlParserException, ServerException, IllegalArgumentException, IOException {
        return minioClient.getPresignedObjectUrl(
                GetPresignedObjectUrlArgs.builder()
                        .method(Method.PUT)
                        .bucket(bucket)
                        .object(objectKey)
                        .expiry(expirySeconds)
                        .build()
        );
    }

    public String presignGet(String objectKey, int expirySeconds) throws InvalidKeyException, ErrorResponseException, InsufficientDataException, InternalException, InvalidResponseException, NoSuchAlgorithmException, XmlParserException, ServerException, IllegalArgumentException, IOException {
        return minioClient.getPresignedObjectUrl(
                GetPresignedObjectUrlArgs.builder()
                        .method(Method.GET)
                        .bucket(bucket)
                        .object(objectKey)
                        .expiry(expirySeconds)
                        .build()
        );
    }

    public boolean objectExists(String objectKey) {
        try {
            return minioClient.statObject(
                io.minio.StatObjectArgs.builder().bucket(bucket).object(objectKey).build()) != null;
        } catch (Exception ex) {
            return false;
        }
    }
}
