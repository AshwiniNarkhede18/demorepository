package com.company.tickert_service.dto;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class CreateTicketRequest {
    @NotBlank
    private String title;
    private String description;
    @NotBlank
    private String departmentId;
    @NotBlank
    private String priority; // LOW, MEDIUM, HIGH, URGENT
}
