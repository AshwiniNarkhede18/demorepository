package com.company.tickert_service.controller;


import java.security.Principal;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.company.tickert_service.dto.*;
import com.company.tickert_service.service.TicketService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService ticketService;
    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<TicketResponse> createTicket(@Valid @RequestBody CreateTicketRequest req, Principal principal) {
        String requesterEmail = principal.getName(); // email from JWT subject
        // Ideally map email->userId via UserClient; but front-end may pass logged-in userId.
        // For now assume JWT subject = user id OR call a UserClient to get id
        // We'll assume subject is email -> need to resolve to userId. Caller should pass header or we can call UserClient.
        // For simplicity, let's assume frontend sends X-User-Id header; fallback to principal.getName()
        String userId = principal.getName();

        TicketResponse resp = ticketService.createTicket(req, userId);
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/my")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<TicketResponse>> myTickets(Principal principal) {
        String userId = principal.getName();
        List<TicketResponse> list = ticketService.getMyTickets(userId);
        return ResponseEntity.ok(list);
    }

    @GetMapping("/dept")
    @PreAuthorize("hasAnyRole('DEPT_HEAD','ADMIN','MANAGER')")
    public ResponseEntity<List<TicketResponse>> deptTickets(@RequestParam String departmentId) {
        List<TicketResponse> list = ticketService.getDeptTickets(departmentId);
        return ResponseEntity.ok(list);
    }

    @PostMapping("/{id}/assign")
    @PreAuthorize("hasAnyRole('DEPT_HEAD','ADMIN','MANAGER')")
    public ResponseEntity<Void> assign(@PathVariable String id, @RequestBody AssignTicketRequest req, Principal principal) {
        String performedBy = principal.getName();
        ticketService.assignTicket(id, req.getAssignedTo(), performedBy);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/comment")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> comment(@PathVariable String id, @RequestBody CommentRequest req, Principal principal) {
        String senderId = principal.getName();
        ticketService.addComment(id, req, senderId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/close")
    @PreAuthorize("hasAnyRole('ASSIGNED','DEPT_HEAD','ADMIN')")
    public ResponseEntity<Void> close(@PathVariable String id, Principal principal) {
        String performedBy = principal.getName();
        ticketService.closeTicket(id, performedBy);
        return ResponseEntity.noContent().build();
    }
}
