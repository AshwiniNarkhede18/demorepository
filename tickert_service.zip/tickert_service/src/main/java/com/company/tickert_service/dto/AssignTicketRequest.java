package com.company.tickert_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class AssignTicketRequest {
    @NotBlank
    private String assignedTo; // user id
}
