package com.company.tickert_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class CommentRequest {
    @NotBlank
    private String message;
    private Boolean internal = false;
    private String attachmentsJson; // optional JSON array string
}
