package com.company.tickert_service.client;

import java.util.List;

import lombok.Data;
@Data
public class UserDto {
    private String id;
    private String fullName;
    private String email;
    private List<String> roles;
    // getters/setters
    // default ctor
}
