package com.company.tickert_service.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
@Configuration
public class KafkaConfig {
    // KafkaTemplate is auto-configured by spring-boot-starter if properties set.
}
