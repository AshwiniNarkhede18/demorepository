package com.company.tickert_service.dto;


import java.time.Instant;
import lombok.Data;
@Data
public class TicketResponse {
    private String id;
    private String ticketNumber;
    private String title;
    private String description;
    private String departmentId;
    private String priority;
    private String status;
    private String raisedBy;
    private String assignedTo;
    private Instant createdAt;
    private Instant updatedAt;
}
