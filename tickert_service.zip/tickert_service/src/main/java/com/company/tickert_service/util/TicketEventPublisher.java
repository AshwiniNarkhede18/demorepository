package com.company.tickert_service.util;


import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
@Component
public class TicketEventPublisher {
    private final KafkaTemplate<String,String> kafkaTemplate;
    public TicketEventPublisher(KafkaTemplate<String,String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }
    public void publish(String topic, String key, String payload) {
        kafkaTemplate.send(topic, key, payload);
    }
}
