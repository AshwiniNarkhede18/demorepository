package com.company.tickert_service.entity;

import java.time.Instant;
import java.util.UUID;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="ticket_events")
@Data
public class TicketEvent {
    @Id
    @Column(length=36)
    private String id;

    @Column(name="ticket_id", length=36)
    private String ticketId;

    @Column(name="event_type", length=50)
    private String eventType;

    @Column(columnDefinition="JSON")
    private String payload;

    @Column(name="performed_by", length=36)
    private String performedBy;

    @Column(name="created_at")
    private Instant createdAt;

    @PrePersist
    public void prePersist() {
        if (this.id == null) this.id = UUID.randomUUID().toString();
        this.createdAt = Instant.now();
    }
}
